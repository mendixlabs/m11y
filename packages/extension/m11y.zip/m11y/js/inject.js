/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
/*!******************************!*\
  !*** ./src/inject/inject.ts ***!
  \******************************/

console.log('🔥 Inject');

/******/ })()
;
//# sourceMappingURL=inject.js.map